<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Message;
use Illuminate\Support\Facades\Auth;
use App\User;

class MessagesController extends Controller
{
    //

    public function __construct()
    {
    	$this->middleware('auth');
    }

		 public function index()
		 {
		    $messages=Message::with('userFrom')->where('user_id_to',Auth::id())->notDeleted()->get();
		//dd($messages);
		return view('home')->with('messages',$messages);
		 	}

		 	public function create(int $id=0,String $subject=''){
		 		if($id === 0){
		 			$users=User::where('id','!=',Auth::id())->get();
		 		}
		 		else{
		 			$users=User::where('id',$id)->get();
		 		}
		 		
		 		if($subject!='')$subject= 'Re:'.$subject;

		 		//dd($users);

		 		//Returns the view with Users table
		 		return view('create')->with(['users'=>$users,'subject'=>$subject]);
		 	}
		
				public function send(Request $request, int $id=0)
				{
					$this->validate($request,[
						'subject'=>'required',
						'body'=>'required',
					]);
						$message=new Message();

						$message->user_id_from=Auth::id();
						$message->user_id_to=$request->input('to');
						$message->subject=$request->input('subject');
						$message->body=$request->input('body');
						$message->save();


						return redirect()->to('/home')->with('status','Message sent successfully!');
				  }

				  	public function sent()
				  	{
				  	//Message sent from Sender(user_id_from) in Messages table
				  	$messages=Message::with('userTo')->where('user_id_from',Auth::id())->get();
				  	//Returns the view of Route'sent' with table name'messages'.
				  	return view('sent')->with('messages',$messages);
				  	}

				  	public function read(int $id)
				  	{
					$messages=Message::with('userFrom')->find($id);
					//To Read the messages 
					$messages->read=true; 
					//Save the read message in database
					$messages->save();
					//Returns the view of Route'read' with table name'messages'.
					return view('read')->with('messages',$messages);
					}

					public function delete(int $id)
					{
						$messages=Message::find($id);
						//To delete the messages as bolean deleted=true
					$messages->deleted=true; 
						//Save the deleted message in database
					$messages->save();
					//Returns the view of Route'delete' with table name'messages'.
					return redirect()->to('/home')->with('status','Messages deleted successfully.');

						}

					public function deleted()
					 {
					    $messages=Message::with('userFrom')->where('user_id_to',Auth::id())->deleted()->get();
					//dd($messages);
					return view('deleted')->with('messages',$messages);
					 	}

					 	public function return(int $id)
					 	{
					 			$messages=Message::find($id);
								$messages->deleted=false;
								return redirect()->to('/home');
					 		}
					 		
}
