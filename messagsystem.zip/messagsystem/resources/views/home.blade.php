@extends('layouts.app')

@section('content')


                   @if(count($messages)>0)
                    <ul class="list-group">
                        
                        @foreach($messages as $msg)
                            <li class="list-group-item">
                              <a href="{{ route('read',$msg->id)  }}">
                              <strong>From: {{$msg->userFrom->name}},{{$msg->userFrom->email}} </strong>| Subject: {{$msg->subject}} 

                              </a> </li>
                          
                        @endforeach
                    </ul>
                     @else

                      No messages!

                      @endif
              
@endsection
