@extends('layouts.app')

@section('content')

From:{{ $messages->userFrom->name}}
<br>
Email:{{ $messages->userFrom->email}}
<br>

Subject:{{ $messages->subject}}
<hr/>

Message:
<br><br>{{ $messages->body}}
<hr>

<a href="{{ route('create',[$messages->userFrom->id,$messages->subject])}}" class="btn btn-primary">Reply</a>
<a href="{{ route('delete',$messages->id)}}" class="btn btn-danger float-right">Delete</a>

@endsection

