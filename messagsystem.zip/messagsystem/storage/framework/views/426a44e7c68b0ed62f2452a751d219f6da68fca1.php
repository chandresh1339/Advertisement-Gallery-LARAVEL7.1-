

<?php $__env->startSection('content'); ?>


                   <?php if(count($messages)>0): ?>
                    <ul class="list-group">
                        
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                            <li class="list-group-item">
		                         <strong>From: <?php echo e($msg->userFrom->name); ?>,<?php echo e($msg->userFrom->email); ?> </strong>| Subject: <?php echo e($msg->subject); ?> 
		                         <a href="<?php echo e(route('return',$msg->id)); ?>" class="btn btn-info float-right btn-sm">Return to Inbox</a>
		                          </li>
                          
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                     <?php else: ?>

                      No messages!

                      <?php endif; ?>
              
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chandreshj\AppData\Roaming\Composer\messagsystem\resources\views/deleted.blade.php ENDPATH**/ ?>