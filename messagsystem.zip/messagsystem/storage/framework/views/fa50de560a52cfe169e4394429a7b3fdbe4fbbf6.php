

<?php $__env->startSection('content'); ?>

 <?php if(count($messages)>0): ?>
                    <ul class="list-group">
                        
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item"><strong>To: <?php echo e($msg->userTo->name); ?>,<?php echo e($msg->userTo->email); ?> </strong>| Subject: <?php echo e($msg->subject); ?>

                            	<?php if($msg->read): ?>
                             <span class="badge badge-success float-right">Read</span> 
                             <?php endif; ?>
                            </li>
                           
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                     <?php else: ?>

                      No messages!

                      <?php endif; ?>
              
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chandreshj\AppData\Roaming\Composer\messagsystem\resources\views/sent.blade.php ENDPATH**/ ?>