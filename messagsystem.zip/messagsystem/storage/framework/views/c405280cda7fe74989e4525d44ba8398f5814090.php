

<?php $__env->startSection('content'); ?>

From:<?php echo e($messages->userFrom->name); ?>

<br>
Email:<?php echo e($messages->userFrom->email); ?>

<br>

Subject:<?php echo e($messages->subject); ?>

<hr/>

Message:
<br><br><?php echo e($messages->body); ?>

<hr>

<a href="<?php echo e(route('create',[$messages->userFrom->id,$messages->subject])); ?>" class="btn btn-primary">Reply</a>
<a href="<?php echo e(route('delete',$messages->id)); ?>" class="btn btn-danger float-right">Delete</a>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chandreshj\AppData\Roaming\Composer\messagsystem\resources\views/read.blade.php ENDPATH**/ ?>