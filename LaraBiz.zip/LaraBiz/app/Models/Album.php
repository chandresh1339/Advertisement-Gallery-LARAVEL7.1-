<?php

namespace LaraBiz\Models;

use Illuminate\Database\Eloquent\Model;

class Album extends Model
{
    public function photos()
    {
    	return $this->hasMany('LaraBiz\Models\Photo');
    }

    public function user()
   {
   	return $this->belongsTo('LaraBiz\User');
   }
}
