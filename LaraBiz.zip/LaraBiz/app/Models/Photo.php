<?php

namespace LaraBiz\Models;

use Illuminate\Database\Eloquent\Model;

class Photo extends Model
{
    public function Album()
    {
    	return $this->belongsTo('LaraBiz\Models\Album');
    }

    public function user()
   {
   	return $this->belongsTo('LaraBiz\User');
   }
}
