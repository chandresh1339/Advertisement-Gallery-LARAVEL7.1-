<?php

namespace LaraBiz\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
//use App\Models\Album;
use LaraBiz\Models\Album;

class AlbumsController extends Controller
{
   		public function __construct()
    {
        $this->middleware('auth',['except'=>['index','show']]);
    }

    public function index()
       			{
       				
              //Get the data from the photos table
       				$alb=Album::get();

       				//Returns table name-Albums with photos
       				return view('albums.index')->with('albums',$alb);
       			}

   	public function create()
   		{
   			return view('albums.create');
		   			}

   public function store(Request $request)
   { 
 	 $this->validate($request,[
 	 	'name'=>'required',
 	 	'description'=>'required',
 	 	'cover_image'=>'required|image'
 	 ]);

 	   $fileNameWithExtension=$request->file('cover_image')->getClientOriginalName();
 	   $filename=pathinfo($fileNameWithExtension,PATHINFO_FILENAME);

 	   $extension= $request->file('cover_image')->getClientOriginalExtension();

 	   $fileNameToStore=$filename.'_'.time().'.'.$extension;
 	   //dd($fileNameToStore);
 	  $request->file('cover_image')->storeAs('public/album_covers',$fileNameToStore);
 

     	$album = new Album();
      
        $album->name = $request->input('name');
        $album->description = $request->input('description');
        //$post->user_id = auth()->user()->id;
        $album->cover_image = $fileNameToStore;
        $album->save();

    return redirect('/albums')->with('success', 'Album Created Successfully');
  
     }


      public function show($id)
        {
     		$alb=Album::with('photos')->find($id);
     		
     		//Returns view of show method for table name-albums with photos
			return view('albums.show')->with('albums',$alb);

         }
  } 
