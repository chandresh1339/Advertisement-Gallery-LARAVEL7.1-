<?php

namespace LaraBiz\Http\Controllers;

use Illuminate\Http\Request;
use LaraBiz\Models\Photo;
use Illuminate\Support\Facades\Storage;

class PhotosController extends Controller
{

	public function __construct()
    {
        $this->middleware('auth',['except'=>['index','show']]);
    }

   public function create(int $albumId)
   		{
   			return view('photos.create')->with('albumId',$albumId);
		   			}

   public function store(Request $request)
   { 
 	 $this->validate($request,[
 	 	'title'=>'required',
 	 	'description'=>'required',
 	 	'photo'=>'required|image'
 	 ]);

 	   $fileNameWithExtension=$request->file('photo')->getClientOriginalName();
 	   $filename=pathinfo($fileNameWithExtension,PATHINFO_FILENAME);

 	   $extension= $request->file('photo')->getClientOriginalExtension();

 	   $fileNameToStore=$filename.'_'.time().'.'.$extension;
 	   //dd($fileNameToStore);
 	  $request->file('photo')->storeAs('public/albums/'.$request->input('album-id'),$fileNameToStore);
 

	     	$photo = new Photo();
	     	
  			 $photo->title = $request->input('title');
	       $photo->description = $request->input('description');
	        //$post->user_id = auth()->user()->id;
	        $photo->photo = $fileNameToStore;
	        $photo->size = $request->file('photo')->getSize();
	        $photo->album_id = $request->input('album-id');
	       $photo->save();

    return redirect('/albums/'.$request->input('album-id'))->with('success', 'Photos uploaded Successfully');
 
     }

     public function show($id)
        {
     		$ph=Photo::find($id);
     		
     		//Returns view of show method for table name-albums with photos
			return view('photos.show')->with('photos',$ph);
			 }


public function destroy($id)
{
	 $photo = Photo::find($id);
//Path to storage location 'albums' folder pointing to album_id attribute in Photos table
				 if(Storage::delete('public/albums/'.$photo->album_id.'/'.$photo->photo)){

				 	//Delete the photo from the disk
						$photo->delete();

				return redirect('/')->with('success', 'Photo deleted Successfully');

				 }//end of if statement


   }
}
