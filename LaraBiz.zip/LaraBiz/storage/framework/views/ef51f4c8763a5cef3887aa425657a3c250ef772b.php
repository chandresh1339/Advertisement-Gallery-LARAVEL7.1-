<?php $__env->startSection('content'); ?>

	<div class="container">
    <h3><?php echo e($photos->title); ?></h3>
    <p><?php echo e($photos->description); ?></p>

    <form action="<?php echo e(route('photo-destroy',$photos->id)); ?>" method="post" class="form-group">
		<?php echo csrf_field(); ?>
    	<?php echo method_field('DELETE'); ?>
<button type="submit" name="button" class="btn btn btn-danger float-right">DELETE</button>
    </form>
    <!--Display the  model 'album' in  album table with id in photos table-->
            <a href="<?php echo e(route('album-show',$photos->album->id)); ?>" class="btn btn-info">Go Back</a>
            <small>Size:<?php echo e($photos->size); ?></small>
            <!--Displays the storage location of 'albums' folder pointing to album_id attribute in Photos table-->
            <img src="/storage/albums/<?php echo e($photos->album_id); ?>/<?php echo e($photos->photo); ?>" alt="<?php echo e($photos->photo); ?>" width="990px">
            <hr/>
          </div>
	<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chandreshj\AppData\Roaming\Composer\LaraBiz\resources\views/photos/show.blade.php ENDPATH**/ ?>