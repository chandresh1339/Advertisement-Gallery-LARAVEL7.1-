	<?php $__env->startSection('content'); ?>
					<div class="container">
							<h2>Create new adv.</h2>

							
							<form method="post" action="<?php echo e(route('album-store')); ?>" enctype="multipart/form-data">
				                    <?php echo e(@csrf_field()); ?>

								               		<div class="form-group">
												    <label for="name">Name:</label>
												    <input type="text" class="form-control" id="name" name="name" placeholder="Enter name">
										    	          </div>
													  <div class="form-group">
													   <label for="description">Description:</label>
															    <textarea class="form-control"  rows="5" name="description" id="description">
															    	</textarea>
													  </div>
										   <div class="form-group">
												    <label for="cover_image">Cover Image:</label>
												    <input type="file" name="cover_image" class="form-control" id="cover_image">
										    	</div>

										    	<button type="submit" class="btn btn-primary">Submit</button>
							    	 
		<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chandreshj\AppData\Roaming\Composer\LaraBiz\resources\views/albums/create.blade.php ENDPATH**/ ?>