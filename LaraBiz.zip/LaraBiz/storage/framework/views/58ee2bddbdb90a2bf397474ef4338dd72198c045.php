	<?php $__env->startSection('content'); ?>
					<div class="container">
							<h2>Upload new photo</h2>
							<form method="post" action="<?php echo e(route('photo-store')); ?>" enctype="multipart/form-data">
				                    <?php echo e(@csrf_field()); ?>

				                    <input type="hidden" name="album-id" value="<?php echo e($albumId); ?>" >
								               		<div class="form-group">
												    <label for="title">Title:</label>
												    <input type="text" class="form-control" id="title" name="title" placeholder="Enter title">
										    	          </div>
													  <div class="form-group">
													   <label for="description">Description:</label>
															    <textarea class="form-control" rows="5" name="description" id="description">
															    	</textarea>
													  </div>
										   <div class="form-group">
												    <label for="photo">Cover Photo:</label>
												    <input type="file" name="photo" class="form-control" id="photo">
										    	</div>

										    	<button type="submit" class="btn btn-primary">Submit</button>
							    	 
		<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\chandreshj\AppData\Roaming\Composer\LaraBiz\resources\views/photos/create.blade.php ENDPATH**/ ?>