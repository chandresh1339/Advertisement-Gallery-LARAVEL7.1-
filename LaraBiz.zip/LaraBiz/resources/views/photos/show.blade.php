@extends('layouts.app')
@section('content')

	<div class="container">
    <h3>{{ $photos->title}}</h3>
    <p>{{ $photos->description }}</p>

    <form action="{{route('photo-destroy',$photos->id)}}" method="post" class="form-group">
		@csrf
    	@method('DELETE')
<button type="submit" name="button" class="btn btn btn-danger float-right">DELETE</button>
    </form>
    <!--Display the  model 'album' in  album table with id in photos table-->
            <a href="{{route('album-show',$photos->album->id)}}" class="btn btn-info">Go Back</a>
            <small>Size:{{ $photos->size }}</small>
            <!--Displays the storage location of 'albums' folder pointing to album_id attribute in Photos table-->
            <img src="/storage/albums/{{ $photos->album_id}}/{{$photos->photo}}" alt="{{$photos->photo}}" width="990px">
            <hr/>
          </div>
	@endsection


