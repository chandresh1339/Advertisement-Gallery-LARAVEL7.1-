@extends('layouts.app')
@section('content')

	<div class="container">
      @if(count($albums)>0)

      <div class="row">
            @foreach($albums as $album)
     
        <div class="col-md-4">
          <div class="card mb-4 shadow-sm">
            <img src="/storage/album_covers/{{$album->cover_image}}" alt="{{$album->cover_image}}" height="200px">
            
            <div class="card-body">
              <p class="card-text">{{$album->description }}</p>
              <div class="d-flex justify-content-between align-items-center">

                <div class="btn-group">
                  <a href="{{route('album-show',$album->id)}}" class="btn btn-sm btn-outline-secondary">View</a>

                  
<!-- AddToAny BEGIN -->
<div class="a2a_kit a2a_kit_size_32 a2a_default_style">
<a class="a2a_dd" href="https://www.addtoany.com/share"></a>
<a class="a2a_button_facebook"></a>
<a class="a2a_button_twitter"></a>
<a class="a2a_button_whatsapp"></a>
<a class="a2a_button_linkedin"></a>
</div>
<script async src="https://static.addtoany.com/menu/page.js"></script>
<!-- AddToAny END -->
             
                  <!--<button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>-->
                </div>
                    <small class="text-muted">{{$album->name }}</small>
             </div>
            </div>
          </div>

        </div>
 @endforeach
    </div>
    @else
      <h3>Welcome!!! CREATE YOUR FIRST AD</h3>
      @endif
    </div>
		@endsection

